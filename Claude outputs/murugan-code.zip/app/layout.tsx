import type { Metadata, Viewport } from "next";
import "lenis/dist/lenis.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Murugan — Portfolio",
  description: "The portfolio of Lord Murugan: projects, skills, tools and testimonials, told through painterly scroll-driven scenes.",
};

export const viewport: Viewport = { themeColor: "#0b0806" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Kalam:wght@400;700&family=Marcellus&family=Noto+Serif+Tamil:wght@600;800&family=Roboto:wght@400;500&display=swap"
        />
        <link rel="preload" as="image" href="/media/hero-poster.webp" />
      </head>
      <body>{children}</body>
    </html>
  );
}
