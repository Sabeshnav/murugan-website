import Preloader from "@/components/Preloader";
import Hero from "@/components/sections/Hero";
import Soorasamharam from "@/components/sections/Soorasamharam";
import LeadingTheDevas from "@/components/sections/LeadingTheDevas";
import Swamimalai from "@/components/sections/Swamimalai";
import AboutMe from "@/components/sections/AboutMe";
import Skills from "@/components/sections/Skills";
import Tools from "@/components/sections/Tools";
import Testimonials from "@/components/sections/Testimonials";
import Contact from "@/components/sections/Contact";
import { SmoothScroll } from "@/lib/scroll";

export default function Page() {
  return (
    <main>
      <SmoothScroll />
      <Preloader />
      <Hero />
      {/* My Projects */}
      <Soorasamharam />
      <LeadingTheDevas />
      <Swamimalai />
      <AboutMe />
      <Skills />
      <Tools />
      <Testimonials />
      <Contact />
    </main>
  );
}
