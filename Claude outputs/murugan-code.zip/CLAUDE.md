# Murugan Portfolio Website — Project Brief

> **Source of truth:** `BUILD_SPEC.md` is the technical spec (scroll choreography, timings,
> asset wiring). This file is the content and context brief. When the two disagree,
> `BUILD_SPEC.md` wins. All on-site copy lives in `lib/content.ts`.

## Concept
A public-facing website presenting the Tamil deity Lord Murugan as if he had a personal
portfolio/resume site — his mythology reframed as projects, skills, tools and testimonials.
Built for posting on reels and as a portfolio piece. AI-generated painterly concept art
images and videos throughout.

**Mythological tradition followed:** Tamil tradition (Kandhar Sashti Kavasam, Sangam
literature, Arupadaiveedu) — not the pan-Indian/Sanskrit Puranic version.

**Visual style:** painterly concept art, consistent across every generated asset.

---

## Running the site
- `npm install` then `npm run dev` → http://localhost:3000
- `npm run build` → static site in `/out` (deploy that folder anywhere).
- `npm run media` → rebuilds `/public/media` from `/Assets` (needs ffmpeg and Python with
  Pillow, numpy and scipy). Run it whenever an asset changes.
- Stack: Next.js (App Router, static export) · GSAP + ScrollTrigger · Framer Motion ·
  Tailwind v4 · Lenis smooth scroll.

## Code map
- `app/page.tsx` — section order · `app/globals.css` — all styling
- `components/sections/` — `Hero`, `Soorasamharam`, `LeadingTheDevas`, `Swamimalai`,
  `AboutMe`, `Skills`, `Tools`, `Testimonials`, `Contact`
- `components/ProjectCaptionCard.tsx` — the one caption card used across My Projects
- `components/ComicBubble.tsx` — speech bubble (About Me calm/wrath, Contact)
- `components/Preloader.tsx` — holds the page until the hero + Soorasamharam clips are loaded
- `lib/content.ts` — **all copy** · `lib/useScrubVideo.ts` — scroll-scrubbed video ·
  `lib/media.ts` — full-file video preloading · `lib/scroll.tsx` — Lenis + scroll locks
- `scripts/build_media.py` — web media pipeline

---

## Final Section Structure (do not add/reorder sections without the user's explicit say-so)

1. **Hero**
2. **My Projects** (renamed from "Work Experience") — I. Soorasamharam · II. Leading the
   Devas · III. The Swamimalai Incident
3. **About Me**
4. **Skills**
5. **Tools I Use**
6. **Testimonials**
7. **Contact**

The whole page is one continuous downward scroll.

Cut from earlier drafts — do not reintroduce unless asked: Eternal Youth skill, Vel Mastery
skill (Vel stays only in Tools), Rooster in Tools, the 8-milestone life timeline,
Deivanai/Valli marriage stories, Tiruttani, Idumban, devotee stories (Arunagirinathar etc.),
Race for the Mango (Ganesha), the Avvaiyar incident, Ganesha/Avvaiyar/Surapadman
testimonials, physical address in Contact.

---

## Asset map (`/Assets` → `/public/media`)

| Asset | Used in |
|---|---|
| `1.mp4` | Hero — scroll-scrubbed camera arc from his back to his face |
| `2.mp4` | Soorasamharam — scrubbed, beam from the Vel, asura → peacock + rooster |
| `3.mp4` | Leading the Devas — scrubbed, dive through the fleet to Murugan on the peacock |
| `4.mp4`–`8.mp4` | Swamimalai clips 1–5 (autoplay, one at a time) |
| `9.mp4` | Tools — static "avatar select" loop with Vel + Peacock hotspots |
| `10.mp4` | Contact — reclining Murugan loop |
| `11.mp4` / `12.mp4` | About Me — calm pattern loop / wrath lava loop |
| `1.png` | About Me panel 1 (full body, shy) |
| `2.png` / `3.png` | About Me calm / wrath busts (white bg cut out by the media script) |
| `4.png` | Skills background (night sky, six-point constellation) |
| `5.png` / `6.png` | Tools dialogs — Vel / Peacock showcase |
| `7a.png` / `7b.png` / `7c.png` | Testimonial avatars — Shiva / The Tamil People / Brahma |
| `8.png` | Contact finale — the Vel that rises behind "யாமிருக்க பயமேன்" |
| `7.png`, `9.png` | Not used (old 3-headshot batch; spare Vel cutout) |

---

## 1. Hero
- `1.mp4` pinned and scroll-scrubbed (both directions): back-view of Murugan seated on a
  cliff, peacock on his left, Vel planted beside him; camera arcs round to the front, he
  opens his eyes and smiles.
- At the end the frame cross-fades out and **"Vanakkam"** fades in, with "I'm Murugan.
  Welcome to my portfolio." Continued scroll carries it up into My Projects.
- "Yaamirukka Bayamen" is **not** in the Hero any more — it's the closing line of Contact.

## 2. My Projects
Each project is a pinned, scroll-scrubbed (or step-played) video with short caption cards,
one per beat — never a wall of text. All three share one caption-card style.

### I. Soorasamharam (`2.mp4`, 8s)
Cards keyed to video time (locked copy):
- **A** (0–0.4s, bottom-right): "The asura Surapadman held a boon: only Shiva's son could
  defeat him. He considered that a guarantee."
- **B** (3.0–6.6s, left-center): "Weapon of choice: the Vel — not built to destroy, built
  to discern."
- **C** (7.0–8.0s, bottom-right, two lines): "Outcome: Surapadman wasn't eliminated. He was
  reassigned." / "The lesson wasn't written in victory. It was written in what he did with
  it afterward."

### II. Leading the Devas (`3.mp4`, 6.1s)
One bottom-center card revealed letter by letter as the video scrubs (paced to the shot's
beats, last word landing as the Vel extends): "Command isn't given. It's earned at the
front of the formation — leading the devas into battle, peacock beneath him, the fleet of
the heavens at his back."

### III. The Swamimalai Incident (`4.mp4`–`8.mp4`)
Five clips, each a "camera glides through a frozen 3D still" shot, played one at a time with
a pull-up transition. Each card appears when its clip ends, holds 1.2s, then scrolling moves
on:
1. Murugan asks Brahma the meaning of Om — "He asked the simplest question in the universe.
   Brahma didn't have an answer."
2. Brahma imprisoned — "Creation can wait. Ignorance can't."
3. The devas plead with Shiva — "With Brahma silenced, creation itself stalled. The devas
   turned to the only one who outranked the problem."
4. Shiva asks for Brahma's release — "Shiva asked him to release Brahma. Murugan agreed — on
   one condition: let him teach first."
5. Murugan teaches Shiva — "The student became the teacher. Even Shiva took his seat on the
   floor for this one."

## 3. About Me
Pinned, scroll-driven:
1. White background, big "About me?" on the left + shy line "Ohh!! You want to know about…
   me?"; full-body shy Murugan (`1.png`) on the right.
2. Both exit; the calm pattern loop (`11.mp4`) fades in; the calm bust (`2.png`) rises from
   the bottom-left with an ivory/gold comic bubble:
   "Ohh!! I'm just… the boy from the hills." + three lines about his names, his birth (six
   sparks, six mothers, Saravana pond) and how easy he is to reach for the good-hearted.
3. Quick switch to the wrath lava loop (`12.mp4`); the fierce bust (`3.png`) in the same
   spot with a red/ember bubble: "Now — if you're the kind who preys on the weak…" + lines
   ending "I just end the version of you that was the problem."
4. The Skills section scrolls up over it.

Speech-bubble text is always HTML, never baked into images.

## 4. Skills
Scroll-driven trump-card / Sangam-era game-select deck over the constellation background
(`4.png`). Three cards fanned at the bottom; each in turn flips while rising to the center to
show its text, then returns to the deck face-down (text side up, dimmed). One scrubbed
timeline, so scrolling up reverses it.

| Card | Hook | Footnote |
|---|---|---|
| I · Tamil Mastery (Class: Scholar) | "Taught the grammar to Agastya. Still the language's favourite subject." | Tamil Kadavul; taught Tamil grammar to Agastya; Thirumurugatruppadai, Thiruppugazh, Kandhar Sashti Kavasam are addressed to him |
| II · Shanmukha Vision (Seer) | "Six-directional awareness. Nothing outside the field of view." | Six faces = mastery over the five senses and the mind |
| III · Transformative Combat (Warrior) | "Doesn't destroy the enemy. Converts them." | Surapadman split and reborn as the peacock (mount) and rooster (banner) |

## 5. Tools I Use
`9.mp4` as a static "avatar select" loop (camera locked, Murugan and the peacock motionless,
only flora and two butterflies move). The Vel and the Peacock carry always-on glowing
hotspots (gold / blue) that brighten on hover; "Tap Peacock or Vel." pulses at the bottom.
Clicking opens a modal with the showcase image (`5.png` / `6.png`) and copy:
- **The Vel** — "Primary weapon · a gift from his mother": the Sakthi Vel from Shakti;
  long, broad, sharp like a mind should be; "Effective range: from a battlefield to the
  inside of your doubts."
- **The Peacock** — "Mount · formerly Surapadman": reborn, reformed and rehired; pride tamed;
  "Top speed: exactly as fast as you can call his rider's name."
Rooster stays cut.

## 6. Testimonials
Mock Google-review cards in a vertical roller (pinned until all three pass), under a mock
place header ("Murugan · 4.9 ★ · ∞ reviews · Open 24 hours, every yuga"). Order and copy:
1. **Shiva** (5★, "Local Guide · 1,008 reviews · Kailasam") — took the student's seat to
   learn the meaning of Om; "Proud father. Humbled student."
2. **The Tamil People** (5★, "Local Guide · Level ∞") — "Been coming here for over two
   thousand years… Five stars feels low."
3. **Brahma** (4★, "Creator · 4 reviews") — couldn't answer what Om means, ended up in a
   cell; "One star off for the cell. Four for the lesson." Owner reply: "Glad the lesson
   stuck. The cell was part of the curriculum."
Each card has a "Based on a true story" chip whose tooltip gives the real incident.

## 7. Contact
`10.mp4` (Murugan reclining on the left) with a comic bubble on the right (locked copy):
"If you wanna contact me: Be rightfully courageous. Do the right thing. Seek knowledge and
humility. Keep purity in thought. Show compassion towards all living beings. Follow these,
and I will be there for you when you need me."
Then the screen turns white, the Vel (`8.png`) rises into frame like a drawn thread, and
**யாமிருக்க பயமேன்** fades in over it, with "Yaamirukka bayamen — Why fear, when I am
here?" beneath. This is the final state of the page.

---

## Character Reference Sheets (painterly concept art, 8-pose turnaround: 5 full-body angles + 3 face close-ups, plain grey background)

- **Murugan** — lean, muscular, chiseled, hunter-eyed young man. Long loose wavy black hair,
  three horizontal white vibhuti stripes with a red dot on the forehead, gold teardrop
  earrings, gold necklace with red ruby pendant, thick white/red/green flower garland, gold
  armlets/bracelets, saffron-orange dhoti with ornate gold belt, red-orange gold-bordered
  angavastram over the left shoulder, barefoot with gold anklets. Always shown holding the
  Vel.
- **The Vel** — tall slender divine spear, broad teardrop-shaped golden blade with three
  horizontal white stripes and a red dot at center, ornate fleur-de-lis base below the blade,
  ornate gold collar/knob, long slender gold shaft.
- **Surapadman** — towering, broad, big round belly, deep dark-brown skin, tall ornate gold
  crown with red gems, long wavy black hair, thick black handlebar mustache, wide glaring
  rageful eyes, snarling fanged mouth, ornate gold-and-dark-steel kavacha with chain details,
  broad shoulder guards, wide gold belt, red dhoti with gold borders, barefoot.
- **Shiva** — broad-shouldered, muscular, cool blue skin, calm face with closed eyes, high
  topknot with a white crescent moon, three vibhuti stripes with a vertical third eye, gold
  hoop earrings, cobra around the neck/shoulder, dark rudraksha necklaces/armbands,
  leopard-skin wrap, Trishul (dark-steel trident, small damaru with an orange-red streamer).
- **Brahma** — elderly, warm golden-tan skin, long white beard/mustache, THREE identical faces
  on one head, three tall ornate golden crowns (center largest, red gem), white vibhuti + red
  tilaka; four arms holding a palm-leaf book, raised in blessing, a rudraksha mala, a small
  gold kamandalu; mustard-yellow top, orange-red gold-bordered angavastram and dhoti. (Tamil
  tradition has him four-faced/Nanmugan; 3-faced is the locked design unless corrected.)
- **Peacock** — adult male Indian peafowl, iridescent cobalt-blue neck/breast, small upright
  crest, long green-gold eyed train.
- **Rooster** — realistic adult rooster, red comb/wattles, crimson-and-gold plumage, long
  arching dark green tail. Appears only in the Soorasamharam transformation.

---

## Standing Production Rules (all future asset generation)

1. **Art style is locked:** painterly concept art, consistent visible brushwork, across every
   image and video. Do not deviate without explicit instruction.
2. **Character sheets are always assumed attached** when generating an established
   character — prompts should not hedge on, or flag, a "missing" reference.
3. **Deliberate camera-angle vocabulary** (over-the-shoulder, low angle, symmetrical, side
   angle, orbit, dolly, slider…) — every new prompt names and commits to a specific angle/move
   and flags which was chosen if the user didn't specify.
4. **Static "game avatar" loops keep the character completely motionless** and move only
   secondary elements (flora, clouds, butterflies, embers), so fixed-position hotspots line up.
5. Do not reintroduce any cut content listed above without the user asking.
6. Cutout/portrait images are best delivered on transparency; white backgrounds work but
   need the media script's cutout step.

---

## Open / Next Tasks

- [ ] Review the copy written during the build (About Me bubbles, Skills hooks/footnotes,
      Tools dialogs, testimonial quotes and tooltips, Hero subline) — all in
      `lib/content.ts`.
- [ ] Run it locally (`npm install && npm run dev`) and check the scroll feel end to end,
      especially the Swamimalai scroll-hold and the Skills deck on a phone.
- [ ] Optional: deploy `/out` (Netlify/Vercel) for a shareable link for reels.
- [x] Build complete to `BUILD_SPEC.md` (2 Oct 2026). Skills background decided: night-sky
      constellation (`4.png`). Contact finale uses `8.png`.
