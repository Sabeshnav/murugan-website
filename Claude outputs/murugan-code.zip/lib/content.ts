// All site copy lives here so it can be edited without touching animation code.
// Lines marked "LOCKED" were approved by the user; everything else was drafted during the
// build and is safe to rewrite.

export const hero = {
  scrollCue: "Scroll to begin",
  greeting: "Vanakkam",
  sub: "I'm Murugan. Welcome to my portfolio.",
};

export const projects = {
  sectionTitle: "My Projects",
  soorasamharam: {
    index: "I",
    title: "Soorasamharam",
    // LOCKED (4 lines; the last two share Card C per BUILD_SPEC)
    cardA: "The asura Surapadman held a boon: only Shiva's son could defeat him. He considered that a guarantee.",
    cardB: "Weapon of choice: the Vel — not built to destroy, built to discern.",
    cardC: [
      "Outcome: Surapadman wasn't eliminated. He was reassigned.",
      "The lesson wasn't written in victory. It was written in what he did with it afterward.",
    ],
  },
  devas: {
    index: "II",
    title: "Leading the Devas",
    card: "Command isn't given. It's earned at the front of the formation — leading the devas into battle, peacock beneath him, the fleet of the heavens at his back.",
  },
  swamimalai: {
    index: "III",
    title: "The Swamimalai Incident",
    cards: [
      "He asked the simplest question in the universe. Brahma didn't have an answer.",
      "Creation can wait. Ignorance can't.",
      "With Brahma silenced, creation itself stalled. The devas turned to the only one who outranked the problem.",
      "Shiva asked him to release Brahma. Murugan agreed — on one condition: let him teach first.",
      "The student became the teacher. Even Shiva took his seat on the floor for this one.",
    ],
  },
};

export const about = {
  heading: "About me?",
  shy: "Ohh!! You want to know about… me?",
  calm: {
    lead: "Ohh!! I'm just… the boy from the hills.",
    lines: [
      "Kumaran, Kandan, Velan, Senthil, Arumugam — call me whatever you like. I'll answer.",
      "Six sparks from my father's third eye, six mothers by the Saravana pond, one me.",
      "To the good-hearted, I'm the easiest god in the universe to reach. Say my name once, sincerely, and I'm already on my way. Peacock fuelled. Vel ready.",
    ],
  },
  wrath: {
    lead: "Now — if you're the kind who preys on the weak…",
    lines: [
      "Ask Surapadman how that went. He had a boon, an army and a fortress on the sea. I had a Vel.",
      "I don't hold grudges. I don't destroy, either.",
      "I just end the version of you that was the problem.",
    ],
  },
};

export const skills = {
  title: "Skills",
  cards: [
    {
      numeral: "I",
      name: "Tamil Mastery",
      cls: "Scholar",
      emblem: "tamil" as const,
      hook: "Taught the grammar to Agastya. Still the language's favourite subject.",
      footnote:
        "Tamil tradition calls him Tamil Kadavul — the god of Tamil. Legend says he taught the language's grammar to the sage Agastya, and whole works are addressed to him: the Sangam-era Thirumurugatruppadai, Thiruppugazh, Kandhar Sashti Kavasam.",
    },
    {
      numeral: "II",
      name: "Shanmukha Vision",
      cls: "Seer",
      emblem: "shatkona" as const,
      hook: "Six-directional awareness. Nothing outside the field of view.",
      footnote:
        "Arumugam, the six-faced one. His six faces stand for mastery over the five senses and the mind — full perceptual command from every direction at once.",
    },
    {
      numeral: "III",
      name: "Transformative Combat",
      cls: "Warrior",
      emblem: "feather" as const,
      hook: "Doesn't destroy the enemy. Converts them.",
      footnote:
        "When he defeated Surapadman, the asura wasn't destroyed. He was split in two and reborn as the peacock (his mount) and the rooster (his banner).",
    },
  ],
};

export const tools = {
  title: "Tools I Use",
  prompt: "Tap Peacock or Vel.",
  vel: {
    name: "The Vel",
    tag: "Primary weapon · a gift from his mother",
    body: [
      "Given to him by his mother, Shakti, before the war — which is why it's called the Sakthi Vel.",
      "Its blade is long, broad and sharp, the way a mind should be: deep, wide, and precise. It doesn't miss, and it never needs a second strike.",
      "Effective range: from a battlefield to the inside of your doubts.",
    ],
  },
  peacock: {
    name: "The Peacock",
    tag: "Mount · formerly Surapadman",
    body: [
      "Half of the asura Surapadman, after the war — reborn, reformed and rehired.",
      "Fast across the sky, loyal beyond question, and a standing reminder that pride can be tamed and nobody is beyond redemption.",
      "Top speed: exactly as fast as you can call his rider's name.",
    ],
  },
};

export const testimonials = {
  place: {
    name: "Murugan",
    category: "Deity · Tamil Kadavul",
    rating: "4.9",
    count: "∞ reviews",
    hours: "Open 24 hours, every yuga",
  },
  reviews: [
    {
      id: "shiva",
      name: "Shiva",
      avatar: "/media/review-shiva.webp",
      meta: "Local Guide · 1,008 reviews · Kailasam",
      stars: 5,
      when: "a few yugas ago",
      text: "I asked my son to release Brahma. He said fine — but first he'd teach me the meaning of Om. So I took the student's seat and listened. Best class I've ever attended. Proud father. Humbled student.",
      helpful: "Helpful (3.3 crore)",
      anchor:
        "Swamimalai: after Brahma's imprisonment, Shiva heard the meaning of the Pranava (Om) from his son as a disciple — which is why Murugan there is called Swaminatha, “teacher of the Lord”.",
    },
    {
      id: "tamil",
      name: "The Tamil People",
      avatar: "/media/review-tamil.webp",
      meta: "Local Guide · Level ∞ · 2,000+ years of reviews",
      stars: 5,
      when: "every single day",
      text: "Been coming here for over two thousand years. Never closed, never late, never once asked us for an appointment. We named our children, our hills and our poetry after him. Five stars feels low.",
      helpful: "Helpful (8 crore)",
      anchor:
        "Tamil Kadavul: the Sangam-era Thirumurugatruppadai sings of him, and Kandhar Sashti Kavasam is still recited in Tamil homes every day.",
    },
    {
      id: "brahma",
      name: "Brahma",
      avatar: "/media/review-brahma.webp",
      meta: "Creator · 4 reviews",
      stars: 4,
      when: "Edited · a kalpa ago",
      text: "Asked me one “simple” question: what does Om mean? I created the universe. I did not know. Next thing I knew, I was in a cell and creation was on hold. One star off for the cell. Four for the lesson — I know what Om means now.",
      helpful: "Helpful (1)",
      anchor:
        "Brahma couldn't explain the meaning of Om to the young Murugan, who imprisoned him until he could — and creation stalled until Shiva stepped in.",
      ownerReply: "Glad the lesson stuck. The cell was part of the curriculum.",
    },
  ],
};

export const contact = {
  // LOCKED
  lead: "If you wanna contact me:",
  values: [
    "Be rightfully courageous.",
    "Do the right thing.",
    "Seek knowledge and humility.",
    "Keep purity in thought.",
    "Show compassion towards all living beings.",
  ],
  close: "Follow these, and I will be there for you when you need me.",
  tamil: "யாமிருக்க பயமேன்",
  translit: "Yaamirukka bayamen",
  translation: "Why fear, when I am here?",
};
