export default function ProjectLabel({ index, title, extra }: { index: string; title: string; extra?: string }) {
  return (
    <div className="project-label">
      <span className="project-label-kicker">My Projects</span>
      <span className="project-label-title">
        <em>{index}</em> {title}
      </span>
      {extra && <span className="project-label-extra">{extra}</span>}
    </div>
  );
}
