"use client";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { gsap, useGSAP } from "@/lib/gsap";
import { lockScroll, unlockScroll } from "@/lib/scroll";
import { tools } from "@/lib/content";

type ToolKey = "vel" | "peacock";

export default function Tools() {
  const section = useRef<HTMLElement>(null);
  const [open, setOpen] = useState<ToolKey | null>(null);
  const [burst, setBurst] = useState<ToolKey | null>(null);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  useGSAP(
    () => {
      gsap
        .timeline({
          scrollTrigger: { trigger: section.current, start: "top top", end: "+=140%", pin: true, scrub: true },
        })
        .fromTo(".tools-prompt", { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.12 }, 0.02)
        .to({}, { duration: 0.6 })
        // continued scroll fades the section out, handing over to Testimonials
        .to(".tools-inner", { opacity: 0, duration: 0.3, ease: "power1.in" });
    },
    { scope: section },
  );

  useEffect(() => {
    if (!open) return;
    lockScroll("tool-modal");
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(null);
    window.addEventListener("keydown", onKey);
    return () => {
      unlockScroll("tool-modal");
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const pick = (k: ToolKey) => {
    setBurst(k);
    window.setTimeout(() => {
      setBurst(null);
      setOpen(k);
    }, 520);
  };

  const data = open ? tools[open] : null;

  return (
    <section ref={section} className="tools-stage">
      <div className="tools-inner">
        <video className="tools-blur" src="/media/tools.mp4" poster="/media/tools-poster.webp" autoPlay muted loop playsInline aria-hidden />
        {/* 16:9 box sized to cover the viewport, so hotspot % coordinates always line up */}
        <div className="tools-frame">
          <video className="absolute inset-0 h-full w-full" src="/media/tools.mp4" poster="/media/tools-poster.webp" autoPlay muted loop playsInline />
          <button
            className={`hotspot hotspot-vel ${burst === "vel" ? "is-burst" : ""}`}
            onClick={() => pick("vel")}
            aria-label="Open the Vel"
          >
            <span className="hotspot-glow" />
            <span className="hotspot-ring" />
          </button>
          <button
            className={`hotspot hotspot-peacock ${burst === "peacock" ? "is-burst" : ""}`}
            onClick={() => pick("peacock")}
            aria-label="Open the Peacock"
          >
            <span className="hotspot-glow" />
            <span className="hotspot-ring" />
          </button>
        </div>
        <h2 className="section-title tools-title">{tools.title}</h2>
        <p className="tools-prompt">{tools.prompt}</p>
      </div>

      {mounted &&
        createPortal(
      <AnimatePresence>
        {open && data && (
          <motion.div
            className="tool-modal-backdrop"
            data-lenis-prevent
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(null)}
          >
            <motion.div
              className={`tool-modal tool-modal-${open}`}
              role="dialog"
              aria-modal="true"
              aria-label={data.name}
              initial={{ opacity: 0, y: 40, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1, transition: { type: "spring", damping: 24, stiffness: 220 } }}
              exit={{ opacity: 0, y: 24, scale: 0.97, transition: { duration: 0.2 } }}
              onClick={(e) => e.stopPropagation()}
            >
              <button className="tool-modal-close" onClick={() => setOpen(null)} aria-label="Close">
                ×
              </button>
              <div className="tool-modal-media">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={open === "vel" ? "/media/tool-vel.webp" : "/media/tool-peacock.webp"} alt={data.name} />
              </div>
              <div className="tool-modal-text">
                <span className="tool-modal-tag">{data.tag}</span>
                <h3>{data.name}</h3>
                {data.body.map((p) => (
                  <p key={p}>{p}</p>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>,
          document.body,
        )}
    </section>
  );
}
