"use client";
import { useRef, useState } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { useScrubVideo } from "@/lib/useScrubVideo";
import ProjectCaptionCard from "../ProjectCaptionCard";
import ProjectLabel from "../ProjectLabel";
import { projects } from "@/lib/content";

const DURATION = 8.0;
const copy = projects.soorasamharam;

/** Which card is on screen is decided by the scrubbed video time, never scroll distance. */
function cardFor(t: number): "A" | "B" | "C" | null {
  if (t < 0.45) return "A";
  if (t >= 3.0 && t < 6.7) return "B";
  if (t >= 7.0) return "C";
  return null;
}

export default function Soorasamharam() {
  const section = useRef<HTMLElement>(null);
  const video = useRef<HTMLVideoElement>(null);
  const setTime = useScrubVideo(video, "sooras");
  const [card, setCard] = useState<"A" | "B" | "C" | null>("A");

  useGSAP(
    () => {
      const proxy = { t: 0 };
      const update = () => {
        setTime(proxy.t);
        setCard(cardFor(proxy.t));
      };
      gsap
        .timeline({
          defaults: { ease: "none" },
          scrollTrigger: { trigger: section.current, start: "top top", end: "+=420%", pin: true, scrub: true },
        })
        // [DECISION] the opening 0.4s is stretched over extra scroll so Card A can be read
        .to(proxy, { t: 0.3, duration: 0.14, onUpdate: update })
        .to(proxy, { t: DURATION, duration: 0.74, onUpdate: update })
        // hold on the final frame so Card C can be read before release
        .to({}, { duration: 0.12 });
    },
    { scope: section },
  );

  return (
    <section ref={section} className="project-stage">
      <video ref={video} className="project-video" poster="/media/sooras-poster.webp" muted playsInline preload="auto" />
      <div className="project-shade" aria-hidden />
      <ProjectLabel index={copy.index} title={copy.title} />
      <ProjectCaptionCard id="A" show={card === "A"} position="bottom-right">
        <p>{copy.cardA}</p>
      </ProjectCaptionCard>
      <ProjectCaptionCard id="B" show={card === "B"} position="left-center">
        <p>{copy.cardB}</p>
      </ProjectCaptionCard>
      <ProjectCaptionCard id="C" show={card === "C"} position="bottom-right">
        <p>{copy.cardC[0]}</p>
        <p className="caption-second">{copy.cardC[1]}</p>
      </ProjectCaptionCard>
    </section>
  );
}
