"use client";
import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import ComicBubble from "../ComicBubble";
import { about } from "@/lib/content";

export default function AboutMe() {
  const section = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const tl = gsap.timeline({
        defaults: { ease: "power2.inOut" },
        scrollTrigger: { trigger: section.current, start: "top top", end: "+=520%", pin: true, scrub: true },
      });
      // 1. "About me?" + shy full-body Murugan
      tl.fromTo(".about-shy", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.6 }, 0.2)
        .to({}, { duration: 0.6 })
        // 2. both exit: image to the right, heading to the left
        .to(".about-p1", { xPercent: 45, opacity: 0, duration: 1.1 }, "exit")
        .to(".about-heading", { xPercent: -45, opacity: 0, duration: 1.1 }, "exit")
        // 3. calm pattern loop fades in
        .to(".about-calm-bg", { opacity: 1, duration: 0.9 }, "exit+=0.6")
        // 4. calm Murugan + bubble
        .fromTo(".about-p2", { yPercent: 30, opacity: 0 }, { yPercent: 0, opacity: 1, duration: 1, ease: "power3.out" }, "exit+=1.1")
        .fromTo(".bubble-calm", { scale: 0.82, opacity: 0, transformOrigin: "0% 100%" }, { scale: 1, opacity: 1, duration: 0.7, ease: "back.out(1.6)" }, "exit+=1.6")
        .to({}, { duration: 1.4 })
        // 5. quick switch to wrath
        .addLabel("wrath")
        .to(".about-p2", { opacity: 0, yPercent: 12, duration: 0.45 }, "wrath")
        .to(".bubble-calm", { opacity: 0, scale: 0.94, duration: 0.35 }, "wrath")
        .to(".about-wrath-bg", { opacity: 1, duration: 0.45 }, "wrath+=0.1")
        // 6. wrath Murugan, same spot, wrath bubble
        .fromTo(".about-p3", { yPercent: 12, opacity: 0 }, { yPercent: 0, opacity: 1, duration: 0.7, ease: "power3.out" }, "wrath+=0.45")
        .fromTo(".bubble-wrath", { scale: 0.82, opacity: 0, transformOrigin: "0% 100%" }, { scale: 1, opacity: 1, duration: 0.6, ease: "back.out(1.8)" }, "wrath+=0.8")
        .to({}, { duration: 1.6 });
    },
    { scope: section },
  );

  return (
    <section ref={section} className="about-stage">
      <video className="about-calm-bg about-bg" src="/media/about-calm.mp4" poster="/media/about-calm-poster.webp" autoPlay muted loop playsInline />
      <video className="about-wrath-bg about-bg" src="/media/about-wrath.mp4" poster="/media/about-wrath-poster.webp" autoPlay muted loop playsInline />

      <div className="about-heading">
        <h2>{about.heading}</h2>
        <p className="about-shy">{about.shy}</p>
      </div>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img className="about-p1" src="/media/about-1.webp" alt="Murugan, shy and flattered" />

      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img className="about-p2 about-bust" src="/media/about-2.webp" alt="Murugan, calm and smiling" />
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img className="about-p3 about-bust" src="/media/about-3.webp" alt="Murugan, fierce, gripping the Vel" />

      <ComicBubble tone="calm" className="about-bubble">
        <p className="bubble-lead">{about.calm.lead}</p>
        {about.calm.lines.map((l) => (
          <p key={l}>{l}</p>
        ))}
      </ComicBubble>
      <ComicBubble tone="wrath" className="about-bubble">
        <p className="bubble-lead">{about.wrath.lead}</p>
        {about.wrath.lines.map((l) => (
          <p key={l}>{l}</p>
        ))}
      </ComicBubble>
    </section>
  );
}
