"use client";
import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { useScrubVideo } from "@/lib/useScrubVideo";
import { hero } from "@/lib/content";

const DURATION = 5.167;

export default function Hero() {
  const section = useRef<HTMLElement>(null);
  const video = useRef<HTMLVideoElement>(null);
  const setTime = useScrubVideo(video, "hero");

  useGSAP(
    () => {
      const proxy = { t: 0 };
      const tl = gsap.timeline({
        defaults: { ease: "none" },
        scrollTrigger: { trigger: section.current, start: "top top", end: "+=360%", pin: true, scrub: true },
      });
      tl.to(".hero-cue", { opacity: 0, y: 12, duration: 0.05 }, 0)
        .to(proxy, { t: DURATION, duration: 0.8, onUpdate: () => setTime(proxy.t) }, 0)
        // cross-fade the final frame out, then "Vanakkam" in
        .to(".hero-video", { opacity: 0, scale: 1.04, duration: 0.09 }, 0.8)
        .fromTo(".hero-greeting", { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.08 }, 0.85)
        .fromTo(".hero-sub", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.06 }, 0.9)
        .to({}, { duration: 0.06 });
    },
    { scope: section },
  );

  return (
    <section ref={section} className="relative h-screen w-full overflow-hidden bg-[var(--ink)]">
      <video
        ref={video}
        className="hero-video absolute inset-0 h-full w-full object-cover"
        poster="/media/hero-poster.webp"
        muted
        playsInline
        preload="auto"
      />
      <div className="hero-vignette absolute inset-0" aria-hidden />
      <div className="hero-cue">
        <span>{hero.scrollCue}</span>
        <i aria-hidden />
      </div>
      <div className="absolute inset-0 grid place-items-center text-center px-6">
        <div>
          <h1 className="hero-greeting">{hero.greeting}</h1>
          <p className="hero-sub">{hero.sub}</p>
        </div>
      </div>
    </section>
  );
}
