"use client";
import { motion } from "framer-motion";
import { useCallback, useEffect, useRef, useState } from "react";
import { ScrollTrigger, useGSAP } from "@/lib/gsap";
import { getLenis, lockScroll, unlockScroll } from "@/lib/scroll";
import ProjectCaptionCard from "../ProjectCaptionCard";
import ProjectLabel from "../ProjectLabel";
import { projects } from "@/lib/content";

const copy = projects.swamimalai;
const CLIPS = [1, 2, 3, 4, 5].map((n) => `/media/swami-${n}.mp4`);
const DURATIONS = [1.281, 2.433, 3.381, 2.202, 2.164];
const DWELL_MS = 1200;
const LOCK = "swamimalai";

/**
 * Five short clips, one at a time. Each clip autoplays when it becomes active; its card
 * appears once the camera move settles (the clip ends), holds for DWELL_MS, and only then
 * does further downward scroll advance to the next clip with a pull-up transition.
 * Scrolling back up never locks.
 */
export default function Swamimalai() {
  const section = useRef<HTMLElement>(null);
  const videos = useRef<(HTMLVideoElement | null)[]>([]);
  const [active, setActive] = useState(-1);
  const [cardOn, setCardOn] = useState<boolean[]>([false, false, false, false, false]);
  const activeRef = useRef(-1);
  const locked = useRef(false);
  const stRef = useRef<ScrollTrigger | null>(null);
  const timers = useRef<number[]>([]);

  const clearTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  const release = useCallback(() => {
    if (!locked.current) return;
    locked.current = false;
    unlockScroll(LOCK);
    // the visitor may already have scrolled further while locked — re-evaluate
    requestAnimationFrame(() => stRef.current && evaluate(stRef.current));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const showCard = useCallback((i: number, on: boolean) => {
    setCardOn((prev) => (prev[i] === on ? prev : prev.map((v, k) => (k === i ? on : v))));
  }, []);

  const activate = useCallback(
    (i: number, forward: boolean) => {
      clearTimers();
      const prev = activeRef.current;
      activeRef.current = i;
      setActive(i);
      if (prev >= 0 && prev !== i) showCard(prev, false);
      const v = videos.current[i];
      if (i < 0 || !v) return;

      if (!forward) {
        // already seen: jump to the settled frame and show the card straight away
        v.pause();
        v.currentTime = Math.max(0, (v.duration || DURATIONS[i]) - 0.05);
        showCard(i, true);
        return;
      }

      locked.current = true;
      lockScroll(LOCK);
      showCard(i, false);
      v.currentTime = 0;
      v.play().catch(() => {});
      let settled = false;
      const settle = () => {
        if (settled || activeRef.current !== i) return;
        settled = true;
        showCard(i, true);
        timers.current.push(window.setTimeout(release, DWELL_MS));
      };
      v.onended = settle;
      // safety net in case "ended" never fires (e.g. playback blocked)
      timers.current.push(window.setTimeout(settle, (DURATIONS[i] + 0.6) * 1000));
    },
    [release, showCard],
  );

  const evaluate = useCallback(
    (st: ScrollTrigger) => {
      if (locked.current) return;
      const cur = activeRef.current;
      let desired: number;
      if (!st.isActive && st.progress === 0) desired = -1;
      else desired = Math.min(4, Math.floor(st.progress * 5));
      if (desired === cur) return;
      if (desired > cur) activate(cur + 1, true); // one clip at a time going forward
      else activate(desired, false);
    },
    [activate],
  );

  useGSAP(
    () => {
      stRef.current = ScrollTrigger.create({
        trigger: section.current,
        start: "top top",
        end: "+=500%",
        pin: true,
        onUpdate: (st) => evaluate(st),
        onToggle: (st) => evaluate(st),
      });
      // Preload all five clips together, well before the section arrives.
      ScrollTrigger.create({
        trigger: section.current,
        start: "top bottom+=150%",
        once: true,
        onEnter: () =>
          videos.current.forEach((v) => {
            if (v && v.preload !== "auto") {
              v.preload = "auto";
              v.load();
            }
          }),
      });
    },
    { scope: section },
  );

  useEffect(
    () => () => {
      clearTimers();
      unlockScroll(LOCK);
    },
    [],
  );

  // keep the Lenis target aligned after a lock so momentum doesn't fling past a clip
  useEffect(() => {
    if (active >= 0) getLenis()?.resize();
  }, [active]);

  return (
    <section ref={section} className="project-stage swami-stage">
      {CLIPS.map((src, i) => (
        <motion.div
          key={src}
          className="swami-layer"
          style={{ zIndex: i + 1 }}
          initial={false}
          animate={
            i === 0 || i <= active
              ? { y: i < active ? "-14%" : "0%", filter: i < active ? "brightness(0.45)" : "brightness(1)" }
              : { y: "100%", filter: "brightness(1)" }
          }
          transition={{ duration: 0.95, ease: [0.76, 0, 0.24, 1] }}
        >
          <video
            ref={(el) => {
              videos.current[i] = el;
            }}
            className="project-video"
            src={src}
            poster={`/media/swami-${i + 1}-poster.webp`}
            muted
            playsInline
            preload="none"
          />
          <div className="project-shade" aria-hidden />
          <ProjectCaptionCard id={`s${i}`} show={cardOn[i] && active === i} position="bottom-center">
            <p>{copy.cards[i]}</p>
          </ProjectCaptionCard>
        </motion.div>
      ))}
      <ProjectLabel index={copy.index} title={copy.title} extra={`${Math.max(active, 0) + 1} / 5`} />
      <div className="swami-dots" aria-hidden>
        {CLIPS.map((_, i) => (
          <span key={i} className={i === active ? "on" : i < active ? "done" : ""} />
        ))}
      </div>
    </section>
  );
}
