"use client";
import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import ComicBubble from "../ComicBubble";
import { contact } from "@/lib/content";

export default function Contact() {
  const section = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      gsap
        .timeline({
          defaults: { ease: "power2.inOut" },
          scrollTrigger: { trigger: section.current, start: "top top", end: "+=360%", pin: true, scrub: true },
        })
        .fromTo(".bubble-contact", { scale: 0.8, opacity: 0, transformOrigin: "0% 100%" }, { scale: 1, opacity: 1, duration: 0.6, ease: "back.out(1.6)" }, 0.1)
        .fromTo(".contact-value", { opacity: 0, x: 10 }, { opacity: 1, x: 0, duration: 0.3, stagger: 0.12 }, 0.4)
        .fromTo(".contact-close", { opacity: 0 }, { opacity: 1, duration: 0.3 }, ">-0.05")
        .to({}, { duration: 1.3 })
        // background turns to white
        .addLabel("white")
        .to(".bubble-contact", { opacity: 0, y: -20, duration: 0.4 }, "white")
        .to(".contact-white", { opacity: 1, duration: 0.8 }, "white+=0.1")
        // the Vel rises into frame like a thread being drawn, then the Tamil fades in over it
        .fromTo(
          ".contact-vel",
          { clipPath: "inset(100% 0% 0% 0%)", yPercent: 14 },
          { clipPath: "inset(0% 0% 0% 0%)", yPercent: 0, duration: 1.3, ease: "power3.out" },
          "white+=0.7",
        )
        .fromTo(".contact-tamil", { opacity: 0, scale: 0.96, filter: "blur(8px)" }, { opacity: 1, scale: 1, filter: "blur(0px)", duration: 0.8 }, "white+=1.5")
        .fromTo(".contact-translation", { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.5 }, "white+=1.9")
        .to({}, { duration: 0.6 });
    },
    { scope: section },
  );

  return (
    <section ref={section} className="contact-stage">
      <video className="contact-video" src="/media/contact.mp4" poster="/media/contact-poster.webp" autoPlay muted loop playsInline />
      <ComicBubble tone="contact" className="contact-bubble">
        <p className="bubble-lead">{contact.lead}</p>
        <ul>
          {contact.values.map((v) => (
            <li key={v} className="contact-value">
              {v}
            </li>
          ))}
        </ul>
        <p className="contact-close">{contact.close}</p>
      </ComicBubble>

      <div className="contact-white" aria-hidden />
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img className="contact-vel" src="/media/finale-vel.webp" alt="" aria-hidden />
      <div className="contact-final">
        <h2 className="contact-tamil" lang="ta">
          {contact.tamil}
        </h2>
        <p className="contact-translation">
          <span>{contact.translit}</span> — {contact.translation}
        </p>
      </div>
    </section>
  );
}
