import type { ReactNode } from "react";

/** Comic-style speech bubble with an ink outline and a tail pointing at the speaker. */
export default function ComicBubble({
  tone,
  className = "",
  children,
}: {
  tone: "calm" | "wrath" | "contact";
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={`bubble bubble-${tone} ${className}`}>
      <div className="bubble-body">{children}</div>
      <span className="bubble-tail" aria-hidden />
    </div>
  );
}
